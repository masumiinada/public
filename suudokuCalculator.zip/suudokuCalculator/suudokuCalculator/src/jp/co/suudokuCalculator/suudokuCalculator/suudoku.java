package jp.co.suudokuCalculator.suudokuCalculator;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/*
 * タイトル：数独計算結果処理
 * 説明    ：9文字9行の入力より数独の解を求める
 *
 * 作成者  ：稲田 真澄
 *
 * 変更履歴：2014.08.10
 *        ：新規登録
 *        ：メモ
 *        プログラムを再帰的にする必要あり。
 */

/*
 * 9文字9行の入力より数独の解を求める
 */
class Sudoku {
	private int[][] board;

	/**
	 * 入力ファイルの内容表示
	 *
	 * @param board
	 * @throws Exception
	 */
	public Sudoku(int[][] board) throws Exception {
		this.board = board;
		// 読み込みファイル表示
		print();
	}

	/**
	 * 読み込んだファイル内容を表示
	 *
	 * @throws Exception
	 */
	public void print() throws Exception { // 9x9のボードを表示
		for (int i = 0; i < 9; i++) {
			for (int j = 0; j < 9; j++) {
				System.out.print(board[i][j] + " ");
			}
			System.out.println();
		}
	}

	/**
	 * 候補位置の計算を行う
	 *
	 * @param x
	 *            int 横軸
	 * @param y
	 *            int 縦軸
	 * @return int[][] 3x3ボックス
	 */
	private int[] getNum(int x, int y) {
		// (x,y)位置の候補の計算
		int[] res = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		for (int i = 0; i < 9; i++) {
			// 横
			res[board[i][y]]++;
			// 縦
			res[board[x][i]]++;
			// 3x3ボックス
			res[board[x / 3 * 3 + i / 3][y / 3 * 3 + i % 3]]++;
		}
		// res[i] : iが縦、横、3x3ボックスで出現した個数
		return res;
	}

	/**
	 * 候補計算
	 *
	 * @param n
	 * @return
	 * @throws Exception
	 */
	public boolean setSolution(int n) throws Exception {
		// ボードの場所n以下に解を設定。OKかどうかを返す。
		// nの位置のx,yを求める
		int x = n / 9, y = n % 9;
		if (n >= 81)
			// nがボードの枠を超えれば無条件でＯＫ
			return true;
		if (board[x][y] != 0)
			// x,yに解が入っていれば次に行く。
			return setSolution(n + 1);
		// x,y位置の候補を求める
		int[] nums = getNum(x, y);
		for (int i = 1; i <= 9; i++) {
			if (nums[i] == 0) {
				// iが候補ならx,yにiを解として設定
				board[x][y] = i;
				if (setSolution(n + 1))
					// 次の候補を探索。
					return true;
			}
		}
		board[x][y] = 0;
		// 候補が存在しない場合falseを返す。
		return false;
	}

	/**
	 * メイン処理
	 *
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			String inputFile = new inputFileView().getInputFile();
			@SuppressWarnings("resource")
			int[][] board = new readFile().readFile(inputFile);
			Sudoku sdk = new Sudoku(board);
			if (sdk.setSolution(0)) {
				System.out.println("解を表示します");
				sdk.print(); // 結果の表示
			} else {
				System.out.println("解は見つかりません");
			}
			Thread.sleep(100000);
		} catch (Exception e) {
			System.err.println("ファイル読み込み時に問題が発生しました。");
		}
	}
}

/*
 * コマンドラインより読み込み対象ファイル取得
 */
class inputFileView {
	/**
	 * 読み込み対象ファイル取得
	 *
	 * @return String フルパス
	 * @throws Exception
	 */
	public String getInputFile() throws Exception {
		System.out.println("読み込み対象ファイルのフルパスを入力してください。");
		Scanner scan = new Scanner(System.in);
		String inputFile = scan.next();
		scan.close();
		return inputFile;
	}
}

/*
 * ファイル内容取得
 */
class readFile implements AutoCloseable {

	/**
	 * コンストラクタ
	 *
	 * @param filePath
	 */
	public readFile() {
	}

	/**
	 * フルパスより、ファイルの読み込みを行う。
	 *
	 * @param filePath
	 *            フルパス
	 * @return int[][] 読み込み結果
	 */
	public int[][] readFile(String filePath) {
		int readResult[][] = new int[9][9];
		String read[] = new String[9];
		try (BufferedReader reader = new BufferedReader(
				new FileReader(filePath))) {
			String str = null;
			int i = 0;
			while ((str = reader.readLine()) != null) {
				read[i] = str;
				i = i + 1;
			}
			i = 0;
			for (int j = 0; j < 9; j++) {
				for (int k = 0; k < 9; k++) {
					if (k < 9) {
						readResult[j][k] = Integer.valueOf(
								read[i].substring(k, k + 1)).intValue();
					}
				}
				i++;
			}
			return readResult;
		} catch (FileNotFoundException e) {
			System.err.println("読み込み対象のファイルは存在しません。");
		} catch (IOException e) {
			System.err.println("読み込み時に問題が生じました。");
		}
		return null;
	}

	@Override
	public void close() throws Exception {
	}

}